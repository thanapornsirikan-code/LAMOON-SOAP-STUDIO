const SHEET_ID = "PASTE_YOUR_GOOGLE_SHEET_ID";
const ADMIN_KEY = "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET";
const TAB = "Orders";
function setup(){const ss=SpreadsheetApp.openById(SHEET_ID);let sh=ss.getSheetByName(TAB)||ss.insertSheet(TAB);if(sh.getLastRow()===0)sh.appendRow(["orderId","createdAt","name","phone","address","note","itemsJson","total","status"]);return "Ready";}
function doPost(e){try{const p=JSON.parse(e.postData.contents||"{}");if(p.action==="createOrder")return out(createOrder(p.order));if(p.adminKey!==ADMIN_KEY)throw new Error("Unauthorized");if(p.action==="listOrders")return out({success:true,orders:listOrders()});if(p.action==="updateStatus")return out(updateStatus(p.orderId,p.status));throw new Error("Unknown action");}catch(err){return out({success:false,message:String(err.message||err)});}}
function createOrder(o){if(!o||!o.name||!o.phone||!o.address||!o.items||!o.items.length)throw new Error("ข้อมูลคำสั่งซื้อไม่ครบ");const id="LM"+Utilities.formatDate(new Date(),"Asia/Bangkok","yyMMddHHmmss")+"-"+Math.floor(Math.random()*90+10);const sh=sheet();sh.appendRow([id,new Date(),o.name,o.phone,o.address,o.note||"",JSON.stringify(o.items),Number(o.total)||0,"รอหยิบสินค้า"]);return {success:true,orderId:id};}
function listOrders(){const v=sheet().getDataRange().getValues();return v.slice(1).reverse().map(r=>({orderId:r[0],createdAt:r[1],name:r[2],phone:r[3],address:r[4],note:r[5],items:JSON.parse(r[6]||"[]"),total:r[7],status:r[8]}));}
function updateStatus(id,status){const sh=sheet(),v=sh.getDataRange().getValues();for(let i=1;i<v.length;i++){if(v[i][0]===id){sh.getRange(i+1,9).setValue(status);return {success:true};}}throw new Error("ไม่พบคำสั่งซื้อ");}
function sheet(){return SpreadsheetApp.openById(SHEET_ID).getSheetByName(TAB)||SpreadsheetApp.openById(SHEET_ID).insertSheet(TAB);}
function out(x){return ContentService.createTextOutput(JSON.stringify(x)).setMimeType(ContentService.MimeType.JSON);}
